CHENAB ENGINEERING – GOOGLE SHEETS + GITHUB SYSTEM
====================================================

FILES
-----
index.html        Main menu
register.html     Register Order/Part
assignment.html   Assign checklist work
update.html       Department daily update
dashboard.html    Progress dashboard
config.js         Google Apps Script API URL
Code.gs           Google Apps Script backend

SETUP
-----
1. Create a Google Sheet.
2. Open Extensions > Apps Script.
3. Paste Code.gs into the Apps Script editor.
4. Save.
5. Run the function "setup" once and authorize it.
6. Deploy > New deployment > Web app.
7. Execute as: Me.
8. Who has access: Anyone with the link (or your organization, if all users are inside the same Google Workspace).
9. Copy the Web App URL.
10. Open config.js and replace:
   PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE
   with your Web App URL.
11. Upload all six website files to the same GitHub Pages repository.
12. Open index.html through GitHub Pages.

GOOGLE SHEET TABS
-----------------
Parts         = one master record for each order/part.
Assignments   = one row for every assigned process task.
Updates       = daily update history.

WORKFLOW
--------
Register Part -> Assign Work -> Department Daily Update -> Dashboard

IMPORTANT
---------
The task library in assignment.html follows the uploaded Master Design -> Casting ->
Metallurgy -> Machining -> Inspection -> Dispatch checklist. It includes the 13
process sections and their checklist checkpoints.

This is a practical starter system. Before production use, add user authentication,
role permissions, file-upload/Google Drive controls, audit trail, validation rules,
and customer-specific acceptance criteria if required.
